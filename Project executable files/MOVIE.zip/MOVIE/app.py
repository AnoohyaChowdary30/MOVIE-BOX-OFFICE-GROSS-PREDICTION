from flask import Flask,render_template,request
import joblib
import numpy as np
import pandas as pd
import pickle
app=Flask(__name__)
#model=joblib.load('random_forest_model.pkl')
model=pickle.load(open('model.pkl','rb'))
scalar=pickle.load(open('scalar.pkl','rb'))
label=pickle.load(open('label.pkl','rb'))
app=Flask(__name__,template_folder='template')
@app.route('/')
def home():
    return render_template('Untitled-1.html')
@app.route('/predict', methods=['POST'])
def predict():
   input_feature=[x for x in request.form.values()]
   input_feature=np.transpose(input_feature)
   input_feature=[np.array(input_feature)]
   print(input_feature)
   names=['budget','genres','popularity','runtime','vote_average','vote_count','release_month','release_DOW']
   data=pd.DataFrame(input_feature,columns=names)
   x=scalar.transform(data)
   prediction=model.predict(data)
   result=int(prediction[0])
   print(result)
   return render_template('result.html', prediction_text='The Revenue Predicted is: {}'.format(result))
if __name__=='__main__':
  app.run(debug=True)